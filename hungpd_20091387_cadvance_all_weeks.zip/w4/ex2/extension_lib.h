#ifndef __EXTENSION_LIB_H__
#define __EXTENSION_LIB_H__

#include "control.h"

int solve(FILE *f);
void findTheBiggestPointsSet(Point *pointList, int amount);
void findTheBiggestLinearPointsSet(Point *pointList, int amount);

#endif