#ifndef __EXTENSION_LIB_H__
#define __EXTENSION_LIB_H__

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define MAXLENGTH 100


#endif