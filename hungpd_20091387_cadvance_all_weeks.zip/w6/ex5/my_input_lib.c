#include "my_input_lib.h"

int menu() {
    int option;

    printf("\n\t\tMENU\n");
    printf("\t1. Select data\n");
    printf("\t2. Quick sort\n");
    printf("\t3. Insertion sort\n");
    printf("\t4. Selection sort\n");
    printf("\t5. More records\n");
    printf("\t6. Exit program\n");
    printf("\nWhich option would you like to choose?\n");

    do {
      option = getInt();
      if (option < 0 || option > 6) {
        printf("Invalid option! Please choose again!\n");
      }
    } while (option < 0 || option > 6);

    return option;
}

int getInt() {
  int result;

  while(scanf("%d",&result) != 1) {
    printf("This is not an integer number. Please retype the input: ");
    while(getchar() != '\n');
  }

  return result;
}

float getFloat() {
  float result;

  while(scanf("%f",&result) != 1) {
    printf("This is not a float number. Please retype the input: ");
    while(getchar() != '\n');
  }

  return result;
}

int getContinueRequest() {
  char result;

  do {
    result = getchar();
    while(getchar() != '\n');
  } while(result != 'Y' 
    && result != 'N' 
    && result != 'y' 
    && result != 'n');

  if(result == 'Y' || result == 'y')
    return 'Y';
  if(result == 'N' || result == 'n')
    return 'N';

  return 0;
}

void* myMalloc(int size, int total) {
  char *result;

  if((result = (char*) malloc((total + 1) * size * sizeof(char))) == NULL) {
    printf("Cannot allocated memory\n");
    return NULL;
  }

  return result;
}

FILE* openFile(char *filename, char *extension) {
  FILE *fileStream;
  if((fileStream = fopen(filename, extension)) == NULL) {
    printf("Cannot open file %s\n", filename);
    return NULL;
  }
  return fileStream;
}

void handleMenu() {
  // Just the pattern
  int choice;

  while(1) {
      choice = menu();

      switch(choice) {
        case 1:
        printf("You choose option %d\n", choice);
        // TODO: Handle option
        continue;
        case 2:
        printf("You choose option %d\n", choice);
        // TODO: Handle option
        continue;
        case 3:
        printf("You choose option %d\n", choice);
        // TODO: Handle option
        continue;
        case 4:
        printf("You choose option %d\n", choice);
        // TODO: Handle option
        continue;
        case 5:
        printf("You choose option %d\n", choice);
        printf("Bye bye\n");
        // TODO: Handle option
        break;
        default:
        printf("It is not an option\n");
        continue;
      }
      break;
    }
}