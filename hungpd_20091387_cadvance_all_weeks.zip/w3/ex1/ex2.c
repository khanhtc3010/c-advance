#include "extension_lib.h"

int main() {

	if(solve() != 0) {
		printf("Error occurs when executing program\n");
		return 1;
	}

	return 0;
}